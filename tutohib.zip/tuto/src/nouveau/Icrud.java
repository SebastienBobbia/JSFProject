package nouveau;

import java.text.ParseException;

public interface Icrud {

	public void ajouter() throws  Exception; 

	public void supprimer() throws  Exception; 

	public void consulter() throws  Exception; 

	public void rechercher() throws Exception;

}
